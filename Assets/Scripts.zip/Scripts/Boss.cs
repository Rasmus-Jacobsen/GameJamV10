using UnityEngine;

public class Boss : Enemy
{


    public override void StartTurn()
    {
        base.StartTurn();
        Player player = FindAnyObjectByType<Player>(); // letar efter spelaren i scenen

        if (player != null) // om spelaren inte �r null.
        {
            
            
            int x = Random.Range(0, 100); // generar ett slumpm�ssigt tal mellan 0 och 100 f�r att best�mma bossens handling.

            if (health <= 121) // om bossens h�lsa �r mindre �n eller lika med 121, utf�r en upps�ttning handlingar baserat p� det slumpm�ssiga talet.
            {
                if (x <= 80) // om det slumpm�ssiga talet �r mindre �n eller lika med 80, utf�r bossattack1.
                {
                    bossattack1(player);
                    canAct = false;
                }
                else // om det slumpm�ssiga talet �r st�rre �n 80
                {
                    Block();
                    canAct = false;
                }
            }
            if (health <= 60) // om bossens h�lsa �r mindre �n eller lika med 60, utf�r en annan upps�ttning handlingar baserat p� det slumpm�ssiga talet.
            {
                if (x <= 40) // om det slumpm�ssiga talet �r mindre �n eller lika med 40
                {
                    bossattack1(player);
                    canAct = false;
                }
                else if (x <= 80) // om det slumpm�ssiga talet �r mindre �n eller lika med 80
                {
                    bossattack2(player);
                    canAct = false;
                }
                else // om det slumpm�ssiga talet �r st�rre �n 80
                {
                    Block();
                    canAct = false;
                }
            }
            if (health <= 30) // om bossens h�lsa �r mindre �n eller lika med 30, utf�r en tredje upps�ttning handlingar baserat p� det slumpm�ssiga talet.
            {
                if (x <= 20) // om det slumpm�ssiga talet �r mindre �n eller lika med 20
                {
                    bossattack1(player);
                    canAct = false;
                }
                else if (x <= 60) // om det slumpm�ssiga talet �r mindre �n eller lika med 60
                {
                    bossattack2(player);
                    canAct = false;
                }
                else if (x <= 80) // om det slumpm�ssiga talet �r mindre �n eller lika med 80
                {
                    bossattack3(player);
                    canAct = false;
                }
                else // om det slumpm�ssiga talet �r st�rre �n 80
                {
                    Block();
                    canAct = false;
                }
            }
        }
    }
}