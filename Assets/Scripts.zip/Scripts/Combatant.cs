using UnityEngine;

public class Combatant : MonoBehaviour
{
    public int health = 80;
    public int attackPower = 20;
    public bool blocking;
    public int energy;
    public bool cooldown;
    public float cooldownTime = 2f;
    public bool canAct = false;
    public int specialattackpower = 40;
    public virtual void StartTurn()
    {
        canAct = true;

    }
    public virtual void TakeDamage(int damage) // fucntion som utf�rs n�r man tar skada 
    {
        if (blocking) // om man blockar 
        {
            damage /= 2; // dela skada med 2
            Debug.Log($"{gameObject.name} is blocking! Damage reduced.");
        }
       
        health -= damage; 

        if (health <= 0) // om h�lsan �r mindre �n eller lika med 0 s� d�r man
        {
            Death();
        }

    }

    
    protected virtual void OnEndTurn() { }

    public virtual void Attack(Combatant target) // fucntion f�r bas attack f�r b�de spelare och fiende
    {

        blocking = false; // block avst�ngd n�r man attackerar
        print($"{gameObject.name} attacks {target.gameObject.name} for {attackPower} damage!");
        target.TakeDamage(attackPower); // utf�r attacken p� target
        canAct = false; // s�tter s� att man inte kan agera mer under samma tur
        OnEndTurn();
        GameManager.Instance.EndTurn(); // avslutar turen n�r functionen �r genomf�rd

    }
    public virtual void Block() // funktuion f�r att blocka f�r b�de spelare och fiende
    {
        canAct = false;
        blocking = true; // s�tter s� block �r sant 
        print($"{gameObject.name} is blocking and will take reduced damage until their next turn!");
        OnEndTurn();
        GameManager.Instance.EndTurn(); // avslutar turen n�r functionen �r genomf�rd
    }

    public virtual void Death()
    {
        Debug.Log($"{gameObject.name} has been defeated!");

        Destroy(gameObject);
        OnEndTurn();
        GameManager.Instance.EndTurn(); // avslutar turen n�r functionen �r genomf�rd

    }
    public void Rest() // function f�r att vila och ge spelaren energi
    {
        canAct = false;
        blocking = false;
        energy++; // �kar energin med 1
        Debug.Log($"{gameObject.name} rests and recovers energy. Current energy: {energy}");
        OnEndTurn();
        GameManager.Instance.EndTurn();
    }


    public virtual void skipturn() // samma som rest men f�r fienden 
    {
        canAct = false;
        blocking = false;
        Debug.Log($"{gameObject.name} skipped their turn.");
        energy++;
        OnEndTurn();
        GameManager.Instance.EndTurn();
    }
    public virtual void SpecialAttack(Combatant target) // special attack functuon f�r b�de spelare och fiende.
    {
        target.TakeDamage(specialattackpower); // utf�r special attacken p� target
        canAct = false;
        blocking = false;
        Debug.Log($"{gameObject.name} special attacks  {target.gameObject.name} for {specialattackpower} damage");
        OnEndTurn();
        GameManager.Instance.EndTurn();
    }
    public virtual void bossattack1(Combatant target) // boss attack numer 1, f�r bossen som g�r mer skada �n en vanlig attack
    {
        canAct = false;
        blocking = false;
        target.TakeDamage(specialattackpower + 10); // best�mmer att boss attacken g�r 10 mer skada �n en vanlig attack
        Debug.Log($"{gameObject.name} attacks {target.gameObject.name} for {attackPower + 10} damage!");
        OnEndTurn();
        GameManager.Instance.EndTurn();
    }
    public virtual void bossattack2(Combatant target)
    {
        canAct = false;
        blocking = false;
        target.TakeDamage(specialattackpower + 20); // best�mmer att boss attacken g�r 20 mer skada �n en vanlig attack
        Debug.Log($"{gameObject.name} performs a devastating strike on {target.gameObject.name} for {attackPower + 20} damage!");
        OnEndTurn();
        GameManager.Instance.EndTurn();
    }
    public virtual void bossattack3(Combatant target)
    {
        canAct = false;
        blocking = false;
        target.TakeDamage(specialattackpower); // best�mmer att boss attacken g�r 30 mer skada �n en vanlig attack
        Debug.Log($"{gameObject.name} performs an special attack on {target.gameObject.name} for {attackPower + 30} damage!");
        OnEndTurn();
        GameManager.Instance.EndTurn();
    }
    public virtual void Bossstats() // function som �kar bossens stats n�r den n�r vissa h�lsostadier
    {
       

    }


}