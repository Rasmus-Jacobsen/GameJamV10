using UnityEngine;
using UnityEngine.UI;

public class Healthbar : MonoBehaviour
{
    public Combatant combatant;
    public float maxHealth;
    public Sprite[] healthSprites;
    public Image displayimage;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        if (combatant != null) 
            
        maxHealth = combatant.health;// s�tt maxHealth till combatantens h�lsa n�r spelet startar.
    }

    // Update is called once per frame
    void Update()
    {
        if (combatant == null || displayimage == null || healthSprites == null || healthSprites.Length == 0) return; // om combatant, displayimage eller healthSprites inte �r korrekt inst�llda, returnera och g�r inget.


        float ratio = Mathf.Clamp01((float)combatant.health / Mathf.Max(1f, maxHealth)); // ber�kna h�lsan som en ratio mellan 0 och 1, d�r maxHealth inte kan vara mindre �n 1.


        int index = Mathf.RoundToInt(ratio * (healthSprites.Length - 1)); // ber�kna indexet f�r healthSprites baserat p� h�lsan, d�r 0 �r full h�lsa och healthSprites.Length - 1 �r ingen h�lsa.
        index = Mathf.Clamp(index, 0, healthSprites.Length - 1); // s�kerst�ll att indexet �r inom giltiga gr�nser f�r healthSprites arrayen.

        displayimage.sprite = healthSprites[index]; // uppdatera displayimage med den korrekta sprite baserat p� combatantens h�lsa.
    }
}
