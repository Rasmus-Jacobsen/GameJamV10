using UnityEngine;
using UnityEngine.SceneManagement;
public class Menuscript : MonoBehaviour
{

    public void PlayGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1); // laddar n�sta scen 
    }
    public void ExitGame()
    {
        Application.Quit(); // st�nger ner applikationen(spelet)
    }
}
