using UnityEngine;
using UnityEngine.UI;

public class Player : Combatant
{
    
    public Button attackButton, blockButton, restButton, specialAttack;



    public LayerMask mask;
    Enemy target;

    public override void StartTurn()
    {
        base.StartTurn();
        Debug.Log("Choose your action!");
        //L�ger till ui listeners f�r knapparna n�r spelarens tur b�rjar
        attackButton.onClick.AddListener(OnAttackButton);
        blockButton.onClick.AddListener(OnBlockButton);
        restButton.onClick.AddListener(OnRestButton);
        specialAttack.onClick.AddListener(OnSpecialAttackButton);

    }


    protected override void OnEndTurn()
    {
        // tar bort listners n�r turen r slut f�r att stoppa duplicering 
        attackButton.onClick.RemoveListener(OnAttackButton);
        blockButton.onClick.RemoveListener(OnBlockButton);
        restButton.onClick.RemoveListener(OnRestButton);
        specialAttack.onClick.RemoveListener(OnSpecialAttackButton);
    }

    private void Update()
    {
        //genom att skicka ut en raycast n�r man trycker p� mus knappen s� definerar man en target f�r n�r man ska attackera
        if (Input.GetMouseButtonDown(0))
        {
            Vector2 worldPoint = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Collider2D col = Physics2D.OverlapPoint(worldPoint, mask);
            if (col != null)
            {
                target = col.GetComponent<Enemy>();
            }
        }
    }
    public void OnSpecialAttackButton()
    {

        if (!canAct) return;

        if (energy < 1)
        {
            return;
        }

        else if (energy >= 1)
        {
            SpecialAttack(target);


        }
    }

    public void OnAttackButton() // attackera target n�r man trycker p� attack knappen.
    {
       
        Attack(target);
    }

    public void OnBlockButton() // blockera
    {
        if (!canAct) return; // stoppar spelaren fr�n att agera om det inte �r hans tur
        Block();
    }
   
    public void OnRestButton() // vila
    {
        if (!canAct) return; 
        Rest();
        
    }
  



}
