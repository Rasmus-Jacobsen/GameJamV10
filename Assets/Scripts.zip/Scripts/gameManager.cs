using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }


    public List<Combatant> combatants = new List<Combatant>(); // En lista av all a fiender och spelare i scenen
    int currentCombatantIndex = 0;
    public Player player;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        currentCombatantIndex = 0;
        combatants[currentCombatantIndex].StartTurn();
    }

    private void Update()
    {
        for (int i = 0; i < combatants.Count; i++)
        {
            if (combatants[i] == null)
            {
                combatants.RemoveAt(i); // om en combatant har d�tt s� tas den bort fr�n listan
            }
        }
        if (combatants.Count <= 1)
        {
            print("byter scen");
            if (combatants[0].gameObject.tag == "Player")
            {
                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1); // om det bara finns en combatant kvar och den �r spelaren s� laddas n�sta scen

            }
            else if (combatants[0].gameObject.tag == "Enemy")
            {
                SceneManager.LoadScene(12); // om det bara finns en combatant kvar och den �r en fiende s� laddas scenen med index 12, som �r en game over scen
            }
        }
    }

    public void EndTurn()
    {

        currentCombatantIndex++;
        if (currentCombatantIndex >= combatants.Count) 
        {
            currentCombatantIndex = 0;  // oms�tter index till 0 n�r det n�r slutet av listan, s� att det b�rjar om fr�n b�rjan
        }

        combatants[currentCombatantIndex].Invoke("StartTurn", 1); // startar n�sta combatants tur efter en kort cooldown


    }
}